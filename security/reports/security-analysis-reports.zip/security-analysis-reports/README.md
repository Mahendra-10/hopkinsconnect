# Security Analysis Reports - HopkinsConnect Deployment

## Overview

This package contains comprehensive security analysis reports for the HopkinsConnect application deployed on Kubernetes (CloudLab/OpenStack environment).

## Contents

### Static Analysis Reports (`static-analysis/`)
- **kubesec-backend-report.json** - Security analysis of backend Kubernetes manifest
- **kubesec-frontend-report.json** - Security analysis of frontend Kubernetes manifest  
- **trivy-backend-full-report.json** - Complete CVE scan of backend container image
- **trivy-backend-summary.txt** - Human-readable vulnerability summary (backend)
- **trivy-frontend-full-report.json** - Complete CVE scan of frontend container image
- **trivy-frontend-summary.txt** - Human-readable vulnerability summary (frontend)
- **STATIC_ANALYSIS_SUMMARY.md** - Comprehensive analysis and findings

### Dynamic Analysis Reports (`dynamic-analysis/`)
- **kube-hunter-report.txt** - Kubernetes penetration testing results
- **kubectl-security-contexts.json** - Pod security configuration audit
- **kubectl-resource-limits.txt** - Resource governance verification
- **kubectl-rbac-permissions.txt** - RBAC permissions audit
- **kubectl-pods-details.txt** - Deployed pods information
- **network-policy-test-results.txt** - Network isolation verification
- **cluster-information.txt** - Overall cluster configuration
- **DYNAMIC_ANALYSIS_SUMMARY.md** - Comprehensive analysis and findings

### Executive Summary
- **OVERALL_SECURITY_ASSESSMENT.md** - Complete security posture assessment

## Tools Used

### Static Analysis
- **kubesec v2.14.2** - Kubernetes manifest security scanner
- **Trivy v0.67.2** - Container image vulnerability scanner

### Dynamic Analysis & Penetration Testing
- **kube-hunter latest** - Kubernetes penetration testing tool
- **kubectl** - Kubernetes security configuration audit
- **Manual testing** - Network policy validation

## Key Findings Summary

### Static Analysis
- **Backend Image**: 8 vulnerabilities (1 HIGH, 4 MEDIUM, 3 LOW)
- **Frontend Image**: 21 vulnerabilities (3 CRITICAL, 2 HIGH, 9 MEDIUM, 7 LOW)
- **Critical CVEs**: CVE-2025-49794 (libxml2), CVE-2025-58050 (pcre2)

### Dynamic Analysis & Penetration Testing
- **4 findings** from kube-hunter penetration testing
- **1 medium-risk vulnerability**: CAP_NET_RAW capability enabled
- **Network isolation**: 100% effective (verified)
- **RBAC**: Least privilege enforced
- **Security score**: 8.5/10

## Deployment Information

- **Platform**: CloudLab/OpenStack with Kubernetes Magnum
- **Cluster**: Single-node Kubernetes cluster (master-only)
- **Application**: HopkinsConnect (Frontend + Backend + SQLite)
- **Images**: mahendra10/hopkinsconnect-backend:v1, mahendra10/hopkinsconnect-frontend:v1

## Important Notes

⚠️ **Historical Snapshot**: All reports in this package reflect the deployment state at the time of security testing (November 13-14, 2025). 

- **Pod IP Addresses**: Pod IPs shown in reports (e.g., `10.100.0.14` for backend) are historical snapshots from when testing was performed. Pod IPs change when pods restart or are recreated, so current pod IPs may differ. Service ClusterIPs (e.g., `10.254.203.151` for backend-service) remain stable and are accurate.
- **Pod Names**: Pod names include unique identifiers that change with each deployment/recreation (e.g., `hopkinsconnect-backend-5bbd55dc89-w7cbk`). This is expected Kubernetes behavior.
- **Security Findings**: All vulnerability counts, CVE identifications, and security assessments remain accurate regardless of pod IP changes.

## Submission Details

- **Student**: Mahendra Shahi, Abdulaziz Andijani
- **Course**: Cloud Computing Security (JHU)
- **Assignment**: Homework 6 - Security Analysis
- **Date**: November 14, 2025

---

For detailed findings, refer to the summary documents in each directory.
