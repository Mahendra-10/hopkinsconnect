# Security Configuration and Best Practices

## Overview

This document details the comprehensive security measures implemented in the HopkinsConnect application deployment on Kubernetes, covering infrastructure security, container security, application security, and network security.

---

## 🔐 Security Measures Implemented

### 1. **Kubernetes Secrets Management**

**Implementation:**
- Created Kubernetes Secret object to store sensitive configuration data
- JWT secret token stored securely in base64-encoded format
- Secrets injected into containers as environment variables (not hardcoded)

**Configuration:**

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: hopkinsconnect-secrets
type: Opaque
data:
  jwt-secret: <base64-encoded-secret>
```

**Backend Deployment Integration:**

```yaml
env:
- name: JWT_SECRET
  valueFrom:
    secretKeyRef:
      name: hopkinsconnect-secrets
      key: jwt-secret
```

**Security Benefits:**
- ✅ Prevents hardcoding credentials in source code
- ✅ Separates secrets from application configuration
- ✅ Base64 encoding prevents accidental exposure in logs
- ✅ Kubernetes RBAC controls access to secrets

**Screenshot to Include:**
- `kubectl get secrets` output
- `kubectl describe secret hopkinsconnect-secrets` (without revealing actual values)

---

### 2. **SSH Key-Based Authentication**

**Implementation:**
- Generated RSA 4096-bit SSH key pair for secure infrastructure access
- Registered public key with OpenStack Keystone
- Used for accessing Kubernetes nodes without password authentication

**Commands Used:**

```bash
ssh-keygen -t rsa -b 4096 -f ~/.ssh/mykey
openstack keypair create --public-key ~/.ssh/mykey.pub mykey
chmod 600 ~/.ssh/mykey
```

**Security Benefits:**
- ✅ Eliminates password-based authentication vulnerabilities
- ✅ 4096-bit RSA provides strong cryptographic security
- ✅ Private key never transmitted over network
- ✅ Prevents brute-force password attacks

**Screenshot to Include:**
- `openstack keypair list` output from OpenStack dashboard
- SSH key creation confirmation

---

### 3. **Container Security Context (Principle of Least Privilege)**

**Backend Container Security Context:**

```yaml
securityContext:
  runAsNonRoot: true              # Container cannot run as root
  runAsUser: 1000                 # Runs as non-privileged user ID 1000
  allowPrivilegeEscalation: false # Prevents gaining additional privileges
  readOnlyRootFilesystem: false   # Allows writes to designated volumes only
```

**Frontend Container Security Context:**

```yaml
securityContext:
  allowPrivilegeEscalation: false # Prevents privilege escalation
  readOnlyRootFilesystem: false   # Nginx needs to write cache files
```

**Security Benefits:**
- ✅ **Reduced Attack Surface**: Containers run as non-root user (UID 1000)
- ✅ **Privilege Escalation Prevention**: `allowPrivilegeEscalation: false` prevents exploits from gaining root
- ✅ **Defense in Depth**: Even if container is compromised, attacker has limited privileges
- ✅ **Compliance**: Meets CIS Kubernetes Benchmark recommendations

**Trade-offs Made:**
- Frontend runs without `runAsNonRoot` to accommodate Nginx requirements
- `readOnlyRootFilesystem: false` allows application data persistence

**Screenshot to Include:**
- `kubectl describe pod <backend-pod>` showing security context
- Output of security context verification command

---

### 4. **Resource Limits and Quotas (DoS Prevention)**

**Implementation:**

```yaml
# Backend Resources
resources:
  limits:
    cpu: "300m"         # Maximum 0.3 CPU cores
    memory: "384Mi"     # Maximum 384 MB RAM
  requests:
    cpu: "100m"         # Guaranteed 0.1 CPU cores
    memory: "128Mi"     # Guaranteed 128 MB RAM

# Frontend Resources
resources:
  limits:
    cpu: "200m"         # Maximum 0.2 CPU cores
    memory: "256Mi"     # Maximum 256 MB RAM
  requests:
    cpu: "50m"          # Guaranteed 0.05 CPU cores
    memory: "64Mi"      # Guaranteed 64 MB RAM
```

**Security Benefits:**
- ✅ **Prevents Resource Exhaustion**: Limits prevent single pod from consuming all node resources
- ✅ **DoS Protection**: Memory limits prevent memory bombs
- ✅ **CPU Throttling**: CPU limits prevent CPU-based DoS attacks
- ✅ **Predictable Performance**: Requests guarantee minimum resources

**Screenshot to Include:**
- `kubectl top pods` showing resource usage
- `kubectl describe pod <pod-name>` showing resource configuration

---

### 5. **Network Policies (Microsegmentation)**

**Implementation:**

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: hopkinsconnect-network-policy
spec:
  podSelector:
    matchLabels:
      app: hopkinsconnect
  policyTypes:
  - Ingress
  - Egress
  ingress:
  # Frontend accepts traffic on port 80
  - from:
    - podSelector:
        matchLabels:
          component: frontend
    ports:
    - protocol: TCP
      port: 80
  # Backend accepts traffic only from frontend on port 3000
  - from:
    - podSelector:
        matchLabels:
          component: frontend
    ports:
    - protocol: TCP
      port: 3000
  egress:
  - {}  # Allow all egress (can be restricted further)
```

**Security Benefits:**
- ✅ **Zero Trust Networking**: Default deny, explicit allow model
- ✅ **East-West Traffic Control**: Restricts pod-to-pod communication
- ✅ **Lateral Movement Prevention**: Compromised frontend can't directly access other services
- ✅ **Microsegmentation**: Network isolation between application tiers

**Traffic Flow:**
```
Internet → Frontend Pod (port 80) ✅ ALLOWED
Frontend → Backend (port 3000)    ✅ ALLOWED
Backend → Frontend                ❌ DENIED (not needed)
External → Backend (port 3000)    ❌ DENIED (only from frontend)
```

**Screenshot to Include:**
- `kubectl get networkpolicies`
- `kubectl describe networkpolicy hopkinsconnect-network-policy`

---

### 6. **Container Image Security**

**Implementation:**

```yaml
# Backend uses specific version tag (not 'latest')
image: mahendra10/hopkinsconnect-backend:v1

# Frontend uses specific version tag
image: mahendra10/hopkinsconnect-frontend:v1
```

**Best Practices Applied:**
- ✅ **Version Pinning**: Using `v1` tag instead of `latest` for reproducibility
- ✅ **Multi-stage Builds**: Frontend uses lightweight `nginx:alpine` base (reduces attack surface)
- ✅ **Platform Targeting**: Built with `--platform linux/amd64` for architecture consistency
- ✅ **Image Registry**: Using Docker Hub public registry (authenticated pushes)

**Screenshot to Include:**
- `kubectl describe pod <pod>` showing image names and tags
- Docker Hub screenshot showing published images

---

### 7. **Persistent Volume Security**

**Implementation:**

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: backend-pv
spec:
  storageClassName: standard
  capacity:
    storage: 5Gi
  accessModes:
    - ReadWriteOnce  # Single node mount, prevents concurrent writes
  hostPath:
    path: "/mnt/data/hopkinsconnect"
```

**Security Benefits:**
- ✅ **ReadWriteOnce**: Prevents multiple pods from simultaneously writing (data corruption prevention)
- ✅ **Isolated Storage**: Each application component has dedicated storage
- ✅ **Data Persistence**: Survives pod restarts without data loss

**Screenshot to Include:**
- `kubectl get pv,pvc` showing persistent volume bindings

---

### 8. **Kubernetes RBAC (Role-Based Access Control)**

**Default Implementation:**
- Kubernetes RBAC enabled by default in cluster
- Service accounts for each pod with minimal permissions
- Controller plane access restricted via kubeconfig

**Service Accounts:**

```bash
$ kubectl get serviceaccounts
NAME      SECRETS   AGE
default   1         3h28m
```

**Security Benefits:**
- ✅ Each pod runs with its own service account
- ✅ Principle of least privilege applied to cluster access
- ✅ API server access controlled via RBAC policies

**Screenshot to Include:**
- `kubectl get serviceaccounts`
- `kubectl auth can-i --list` (shows what default service account can do)

---

### 9. **OpenStack Infrastructure Security**

**Implemented at Infrastructure Layer:**

1. **Project Isolation:**
   - Dedicated OpenStack project/tenant for deployment
   - Network isolation between projects

2. **Security Groups (Firewall Rules):**
   - OpenStack Magnum automatically creates security groups
   - Restricts traffic to Kubernetes cluster

3. **Private Networking:**
   - Kubernetes nodes on private OpenStack network (10.0.0.0/24)
   - Pods on isolated Pod network (10.100.0.0/16)
   - Floating IPs for external access only where needed

**Screenshot to Include:**
- OpenStack Horizon dashboard showing security groups
- Network topology from OpenStack dashboard

---

### 10. **Secure Container Runtime Configuration**

**Docker/containerd Security:**
- Containers run in isolated namespaces
- Control groups (cgroups) enforce resource limits
- SELinux/AppArmor policies (Fedora CoreOS default)

**Kubernetes Node Security:**

```bash
# Fedora CoreOS with automatic updates
OS-IMAGE: Fedora CoreOS 35.20220116.3.0
KERNEL: 5.15.17-200.fc35.x86_64
CONTAINER-RUNTIME: docker://20.10.11
```

**Security Benefits:**
- ✅ Immutable OS (Fedora CoreOS)
- ✅ Automatic security updates
- ✅ SELinux enabled by default
- ✅ Minimal OS attack surface

**Screenshot to Include:**
- `kubectl get nodes -o wide` showing OS and runtime versions

---

## 🚫 Security Measures NOT Implemented (Limitations)

### 1. **TLS/SSL Encryption**
- **Status**: ❌ Not implemented
- **Impact**: Traffic between services is unencrypted (HTTP not HTTPS)
- **Reason**: Development/homework environment
- **Production Recommendation**: Implement TLS using cert-manager and Let's Encrypt

### 2. **Multi-Factor Authentication (MFA)**
- **Status**: ❌ Not implemented at application level
- **Impact**: User authentication relies on single-factor (password/JWT)
- **Reason**: Application design limitation
- **Production Recommendation**: Implement OAuth2/OIDC with MFA providers (Google, Okta)

### 3. **Pod Security Policies/Standards**
- **Status**: ⚠️ Partial (using security contexts but no cluster-wide enforcement)
- **Impact**: No cluster-wide policy preventing privileged pods
- **Reason**: PSP deprecated in Kubernetes 1.25+
- **Production Recommendation**: Implement Pod Security Standards (restricted profile)

### 4. **Encryption at Rest**
- **Status**: ❌ Not implemented
- **Impact**: Data in PersistentVolumes stored unencrypted
- **Reason**: HostPath storage doesn't support encryption
- **Production Recommendation**: Use encrypted storage class (AWS EBS, GCP PD)

### 5. **Image Vulnerability Scanning**
- **Status**: ❌ Not implemented in CI/CD
- **Impact**: No automated detection of CVEs in container images
- **Reason**: No CI/CD pipeline configured
- **Production Recommendation**: Implement Trivy, Clair, or Snyk scanning

### 6. **Network Encryption (Service Mesh)**
- **Status**: ❌ Not implemented
- **Impact**: Pod-to-pod traffic unencrypted (plaintext HTTP)
- **Reason**: Complexity for homework assignment
- **Production Recommendation**: Implement Istio or Linkerd for mTLS

### 7. **Secrets Encryption at Rest**
- **Status**: ⚠️ Partial (base64 encoding only)
- **Impact**: Secrets stored in etcd are not encrypted at rest
- **Reason**: Requires additional etcd configuration
- **Production Recommendation**: Enable encryption provider in kube-apiserver

---

## 📊 Security Summary Table

| Security Control | Status | Implementation Level | Production-Ready? |
|-----------------|--------|---------------------|-------------------|
| Secrets Management | ✅ Implemented | Kubernetes Secrets | ⚠️ Needs encryption at rest |
| SSH Key Auth | ✅ Implemented | 4096-bit RSA | ✅ Yes |
| Container Security Context | ✅ Implemented | Non-root, no privilege escalation | ✅ Yes |
| Resource Limits | ✅ Implemented | CPU/Memory quotas | ✅ Yes |
| Network Policies | ✅ Implemented | Pod-to-pod isolation | ✅ Yes |
| Image Version Pinning | ✅ Implemented | Tagged versions | ✅ Yes |
| RBAC | ✅ Default | Kubernetes default RBAC | ⚠️ Needs tuning |
| TLS/SSL | ❌ Not Implemented | N/A | ❌ Required for production |
| MFA | ❌ Not Implemented | N/A | ❌ Required for production |
| Vulnerability Scanning | ❌ Not Implemented | N/A | ❌ Required for production |

---

## 📸 Screenshots Required

### Screenshot 1: Kubernetes Secrets
```bash
kubectl get secrets
kubectl describe secret hopkinsconnect-secrets
```
**Shows**: Secret object exists and stores JWT token securely

---

### Screenshot 2: Pod Security Context
```bash
kubectl get pod <backend-pod-name> -o jsonpath='{.spec.containers[0].securityContext}' | python3 -m json.tool
```
**Shows**: Container runs as non-root user with security restrictions

---

### Screenshot 3: Resource Limits
```bash
kubectl describe pod <backend-pod-name> | grep -A 10 "Limits:"
kubectl top pods
```
**Shows**: CPU and memory limits enforced

---

### Screenshot 4: Network Policy
```bash
kubectl get networkpolicies
kubectl describe networkpolicy hopkinsconnect-network-policy
```
**Shows**: Network segmentation between components

---

### Screenshot 5: OpenStack Security Groups
- Navigate to: OpenStack Horizon → Network → Security Groups
**Shows**: Firewall rules protecting Kubernetes cluster

---

### Screenshot 6: SSH Keypair
```bash
openstack keypair list
```
**Shows**: SSH key-based authentication configured

---

### Screenshot 7: Container Images
```bash
kubectl describe pods | grep "Image:"
```
**Shows**: Version-pinned container images (not using 'latest')

---

### Screenshot 8: Service Accounts
```bash
kubectl get serviceaccounts
kubectl get pods -o yaml | grep serviceAccountName
```
**Shows**: RBAC service accounts in use

---


## 🔒 Security Best Practices Summary

### What did we do Well ✅
1. **Defense in Depth**: Multiple security layers (network, container, infrastructure)
2. **Least Privilege**: Non-root containers, minimal RBAC permissions
3. **Resource Protection**: CPU/memory limits prevent resource-based attacks
4. **Network Isolation**: Network policies segment traffic between components
5. **Secrets Management**: No hardcoded credentials
6. **Authentication**: Strong SSH key-based infrastructure access

### What Could Be Improved 🔧
1. **Encryption**: TLS for in-transit data, encryption at rest for secrets
2. **Monitoring**: Security logging and audit trails
3. **Vulnerability Scanning**: Automated CVE detection in images
4. **MFA**: Multi-factor authentication for user access
5. **Pod Security Standards**: Cluster-wide security policy enforcement
6. **Image Scanning**: Pre-deployment vulnerability assessment

---

## 📚 References

1. **CIS Kubernetes Benchmark**: https://www.cisecurity.org/benchmark/kubernetes
2. **OWASP Kubernetes Security Cheat Sheet**: https://cheatsheetseries.owasp.org/cheatsheets/Kubernetes_Security_Cheat_Sheet.html
3. **Kubernetes Security Best Practices**: https://kubernetes.io/docs/concepts/security/
4. **NSA Kubernetes Hardening Guide**: https://media.defense.gov/2022/Aug/29/2003066362/-1/-1/0/CTR_KUBERNETES_HARDENING_GUIDANCE_1.2_20220829.PDF

---

**Document Created**: November 13, 2025  
**Deployment**: HopkinsConnect on OpenStack Kubernetes Cluster  
**Author**: Mahendra Shah (Homework 6)

