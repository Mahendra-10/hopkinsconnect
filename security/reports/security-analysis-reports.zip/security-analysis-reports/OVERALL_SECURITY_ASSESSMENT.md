# Overall Security Assessment - HopkinsConnect Deployment

## Executive Summary

This document provides a comprehensive security assessment of the HopkinsConnect application deployed on a Kubernetes cluster within a CloudLab/OpenStack environment. The assessment includes both static analysis of configurations and container images, as well as dynamic penetration testing of the running system.

## Methodology

### Static Analysis
- **Kubernetes Manifest Analysis** (kubesec): Evaluated deployment configurations for security best practices
- **Container Image Scanning** (Trivy): Identified known vulnerabilities (CVEs) in base images and dependencies

### Dynamic Analysis & Penetration Testing
- **Active Penetration Testing** (kube-hunter): Simulated attacks against the Kubernetes cluster
- **Network Security Testing** (NMAP, Nikto): Validated network segmentation and web security
- **Configuration Audit** (kubectl): Verified security controls in production environment

## Key Findings

### Static Analysis Results

#### Kubernetes Configuration Security
**✅ Strengths:**
- Containers run as non-root users (backend: UID 1000)
- Privilege escalation disabled (`allowPrivilegeEscalation: false`)
- Resource limits enforced (CPU and memory)
- Network policies implemented for pod isolation

**⚠️ Areas for Improvement:**
- Writable root filesystems (required for application functionality)
- Frontend runs as root (Nginx requirement)
- Could implement capabilities drop (CAP_NET_RAW)

**Security Score: 8/10**

#### Container Image Vulnerabilities

**Backend Image (mahendra10/hopkinsconnect-backend:v1):**
- Total: 8 vulnerabilities
  - 1 HIGH: CVE-2024-21538 (cross-spawn ReDoS)
  - 4 MEDIUM: OpenSSL vulnerabilities (CVE-2025-9230, CVE-2025-9231)
  - 3 LOW: Various minor issues
- Application dependencies: ✅ CLEAN (0 vulnerabilities)
- Base image: Alpine 3.21.3

**Frontend Image (mahendra10/hopkinsconnect-frontend:v1):**
- Total: 21 vulnerabilities
  - 3 CRITICAL: CVE-2025-49794 (libxml2 UAF), CVE-2025-49796 (libxml2 type confusion), CVE-2025-58050 (pcre2 heap overflow)
  - 2 HIGH: CVE-2025-49795 (libxml2 null pointer), CVE-2025-6021 (libxml2 integer overflow)
  - 9 MEDIUM: curl, openssl, libexpat issues
  - 7 LOW/UNKNOWN: Minor issues
- Base image: Alpine 3.22.0 (outdated)

**Critical Vulnerabilities Requiring Immediate Attention:**
1. **CVE-2025-49794** - libxml2 Heap Use-After-Free (CVSS: 9.8 Critical)
   - Impact: Remote code execution, DoS
   - Remediation: Update Alpine to 3.22.1+ (libxml2 2.13.9-r0)

2. **CVE-2025-49796** - libxml2 Type Confusion (CVSS: 9.8 Critical)
   - Impact: Denial of service
   - Remediation: Update Alpine to 3.22.1+ (libxml2 2.13.9-r0)

3. **CVE-2025-58050** - pcre2 Heap Buffer Overflow (CVSS: 9.1 Critical)
   - Impact: Memory corruption, potential RCE
   - Remediation: Update Alpine to 3.22.1+ (pcre2 10.46-r0)

---

### Dynamic Analysis & Penetration Testing Results

#### Security Controls Validated ✅

1. **Security Contexts** - PASS
   - Backend runs as UID 1000 (non-root)
   - Privilege escalation disabled on all containers
   - Verified in production environment

2. **Resource Limits** - PASS
   - Backend: 300m CPU / 384Mi memory (enforced)
   - Frontend: 200m CPU / 256Mi memory (enforced)
   - DoS prevention confirmed

3. **RBAC (Role-Based Access Control)** - PASS
   - Default service account: Read-only API discovery only
   - Cannot list secrets, create pods, or modify cluster
   - Least privilege principle enforced

4. **Network Policies** - PASS
   - Backend unreachable from unauthorized pods
   - DNS resolution blocked for isolated services
   - 100% effective isolation confirmed

5. **Attack Surface Minimization** - PASS
   - NMAP port scans blocked by network policies
   - Nikto web scans unable to reach pods directly
   - Only authorized Services can access pods

#### Penetration Testing Findings (kube-hunter)

**Vulnerability 1: CAP_NET_RAW Enabled**
- **Severity**: 🟠 MEDIUM
- **MITRE Category**: Lateral Movement // ARP Poisoning
- **Description**: Pods have CAP_NET_RAW capability, allowing network packet crafting
- **Impact**: Attacker who compromises a pod could perform ARP spoofing, packet sniffing on same node
- **Remediation**: Drop NET_RAW capability in security context
- **Risk**: MEDIUM (requires initial pod compromise, limited to same-node attacks)

**Vulnerability 2: AWS Metadata Exposure (KHV053)**
- **Severity**: ℹ️ INFORMATIONAL (False Positive)
- **Description**: Tool checked for AWS metadata endpoint (169.254.169.254)
- **Impact**: None - cluster not on AWS infrastructure
- **Risk**: NONE

**Vulnerability 3: Access to Pod's Secrets**
- **Severity**: 🟡 LOW-MEDIUM
- **MITRE Category**: Credential Access
- **Description**: Service account tokens mounted at `/var/run/secrets/kubernetes.io/serviceaccount/`
- **Impact**: Attacker with pod access can read JWT tokens
- **Mitigating Factor**: ✅ RBAC limits token to read-only API discovery
- **Risk**: LOW (mitigated by RBAC)

**Vulnerability 4: Service Account Token Readable (KHV050)**
- **Severity**: 🟠 MEDIUM
- **MITRE Category**: Credential Access
- **Description**: JWT tokens accessible and usable for API authentication
- **Impact**: Could make Kubernetes API calls
- **Mitigating Factor**: ✅ Token limited to read-only permissions by RBAC
- **Risk**: MEDIUM (partially mitigated)

---

## Risk Assessment Matrix

| Finding | Severity | Exploitability | Impact | Mitigated? | Overall Risk |
|---------|----------|----------------|--------|------------|--------------|
| **CVE-2025-49794** (libxml2 UAF) | CRITICAL | High | Critical | ❌ No | 🔴 CRITICAL |
| **CVE-2025-49796** (libxml2 type confusion) | CRITICAL | High | High | ❌ No | 🔴 CRITICAL |
| **CVE-2025-58050** (pcre2 overflow) | CRITICAL | Medium | Critical | ❌ No | 🔴 CRITICAL |
| **CVE-2024-21538** (cross-spawn) | HIGH | Medium | Medium | ❌ No | 🟠 HIGH |
| **CAP_NET_RAW** | MEDIUM | High | Medium | ❌ No | 🟠 MEDIUM |
| **Service Account Tokens** | MEDIUM | High | Low | ✅ Yes (RBAC) | 🟡 LOW |
| **OpenSSL vulnerabilities** | MEDIUM | Low | Medium | ❌ No | 🟡 LOW-MEDIUM |

---

## Security Posture Score

### Overall Assessment: **6.5/10** (MODERATE)

**Breakdown:**
- **Configuration Security**: 8/10 ✅ (Strong RBAC, network policies, resource limits)
- **Container Security**: 4/10 ⚠️ (3 critical CVEs in frontend, 1 high in backend)
- **Runtime Security**: 8/10 ✅ (Non-root containers, effective isolation)
- **Network Security**: 10/10 ✅ (Excellent segmentation and access control)

**For Development/Homework Environment**: **ACCEPTABLE** ✅  
**For Production Deployment**: **REQUIRES HARDENING** ⚠️

---

## Recommended Remediation Steps

### Critical Priority 

1. **Update Frontend Base Image:**
   ```dockerfile
   FROM nginx:alpine3.22.1  # Updated from 3.22.0
   ```
   Resolves: CVE-2025-49794, CVE-2025-49796, CVE-2025-58050, CVE-2025-49795, CVE-2025-6021

2. **Update Backend Base Image:**
   ```dockerfile
   FROM node:23-alpine3.21.4  # Updated from 3.21.3
   ```
   Resolves: OpenSSL vulnerabilities (CVE-2025-9230, CVE-2025-9231, CVE-2025-9232)

3. **Update Node.js Dependencies:**
   ```bash
   npm update cross-spawn brace-expansion
   ```
   Resolves: CVE-2024-21538, CVE-2025-5889

### High Priority 
4. **Drop CAP_NET_RAW Capability:**
   ```yaml
   securityContext:
     capabilities:
       drop:
         - ALL
         - NET_RAW
   ```

5. **Implement Pod Security Standards:**
   ```yaml
   apiVersion: policy/v1
   kind: PodSecurityPolicy
   metadata:
     name: restricted
   spec:
     requiredDropCapabilities:
       - ALL
   ```

### Medium Priority 

6. **Disable Service Account Auto-Mounting (if not needed):**
   ```yaml
   spec:
     automountServiceAccountToken: false
   ```

7. **Run Frontend as Non-Root:**
   - Reconfigure Nginx to run as non-root user
   - Set `runAsNonRoot: true` and `runAsUser: 101`

8. **Enable Read-Only Root Filesystem (where possible):**
   ```yaml
   securityContext:
     readOnlyRootFilesystem: true
   ```

---

## Conclusion

The HopkinsConnect deployment demonstrates **strong configuration security** with effective network segmentation, RBAC policies, and resource governance. However, **critical vulnerabilities in container base images** significantly increase risk and require immediate remediation before production use.

### Strengths
✅ Excellent network isolation (network policies working perfectly)  
✅ Strong RBAC implementation (least privilege enforced)  
✅ Proper resource limits (DoS prevention in place)  
✅ Non-root containers (backend follows best practices)  
✅ Penetration testing blocked by security controls  

### Weaknesses
⚠️ 3 CRITICAL CVEs in frontend base image (libxml2, pcre2)  
⚠️ 1 HIGH CVE in backend Node.js dependencies  
⚠️ CAP_NET_RAW enabled (allows network attacks)  
⚠️ Service account tokens accessible (partially mitigated)  


---

**Assessment Date**: November 14, 2025  
**Assessor**: Security Analysis Tools (kubesec, Trivy, kube-hunter) + Manual Review  
**Environment**: CloudLab/OpenStack + Kubernetes Magnum  
